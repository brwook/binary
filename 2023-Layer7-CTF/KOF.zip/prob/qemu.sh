qemu-system-x86_64 -cpu kvm64,+smep \
  -m 64M \
  -kernel ./bzImage \
  -initrd ./kof.cpio \
  -nographic \
  -monitor /dev/null \
  -no-reboot \
  -append "kaslr root=/dev/ram rw rdinit=/root/init console=ttyS0 loglevel=3 oops=panic panic=1"
